from google.cloud import aiplatform

aiplatform.init(project="jobmatching-442612")
print("Google Cloud AI Platform initialized successfully!")
