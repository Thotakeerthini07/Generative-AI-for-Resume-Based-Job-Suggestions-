from google.cloud import aiplatform

# Initialize AI Platform
aiplatform.init(project="jobmatching-442612")
